<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\GuruController;
use App\Http\Controllers\SiswaController;
use App\Http\Controllers\StaffController;
use App\Http\Controllers\UserController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
// 'index' didapat dari HomeController bagian public function index
Route::get('/', [HomeController::class, 'index']);

        Route::get('/guru', [GuruController::class, 'index'])->name('guru');
        Route::get('/guru/detail/{id_guru}', [GuruController::class, 'detail']);
        Route::get('/guru/tambah', [GuruController::class, 'tambah']);
        Route::post('/guru/insert', [GuruController::class, 'insert']);
        Route::get('/guru/edit/{id_guru}', [GuruController::class, 'edit']);
        Route::post('/guru/update/{id_guru}', [GuruController::class, 'update']);
        Route::get('/guru/delete/{id_guru}', [GuruController::class, 'delete']);


        // Siswa
        Route::get('/siswa', [SiswaController::class, 'index'])->name('siswa');
        Route::get('siswa/detail/{id_siswa}', [SiswaController::class, 'detail']);
        Route::get('/siswa/tambah', [SiswaController::class, 'tambah']);
        Route::post('/siswa/insert', [SiswaController::class, 'insert']);
        Route::get('/siswa/edit/{id_siswa}', [SiswaController::class, 'edit']);
        Route::post('/siswa/update/{id_siswa}', [SiswaController::class, 'update']);
        Route::get('/siswa/delete/{id_siswa}', [SiswaController::class, 'delete']);

        // staff
        Route::get('/staff', [StaffController::class, 'index'])->name('staff');
        Route::get('staff/detail/{id_staff}', [StaffController::class, 'detail']);
        Route::get('/staff/tambah', [StaffController::class, 'tambah']);
        Route::post('/staff/insert', [StaffController::class, 'insert']);
        Route::get('/staff/edit/{id_staff}', [StaffController::class, 'edit']);
        Route::post('/staff/update/{id_staff}', [StaffController::class, 'update']);
        Route::get('/staff/delete/{id_staff}', [StaffController::class, 'delete']);

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::get('/user', [UserController::class, 'index'])->name('user');
Route::get('/user/detail/{id}', [UserController::class, 'detail']);
Route::get('/user/edit/{id}', [UserController::class, 'edit']);
Route::post('/user/update/{id}', [UserController::class, 'update']);

