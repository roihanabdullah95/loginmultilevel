@extends('layouts.master')
@section('title','Detail Guru')


@section('content')

<table class="table">
    <tr>
        <th width="150px">Nama</th>
        <th width="30px">:</th>
        <th>{{ $guru->nama_guru }}</th>
    </tr>
    <tr>
        <th width="150px">NIP</th>
        <th width="30px">:</th>
        <th>{{ $guru->nip }}</th>
    </tr>
    <tr>
        <th width="150px">Mata Pelajaran</th>
        <th width="30px">:</th>
        <th>{{ $guru->mapel }}</th>
    </tr>
    <tr>
        <th width="150px">Alamat</th>
        <th width="30px">:</th>
        <th>{{ $guru->alamat }}</th>
    </tr>
    <tr>
        <th width="150px">Foto</th>
        <th width="30px">:</th>
        <th><img src="{{ url('foto_guru/'.$guru->foto) }}" width="200px"></th>
    </tr>
    <tr>
        <th><a href="/guru" class="btn btn-success tbn-sm">Kembali</a></th>
    </tr>
    

</table>






@endsection