@extends('layouts.master')
@section('title','DATABASE GURU')

@section('content')

<div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <a href="/guru/tambah" class="btn btn-warning mb-1">TAMBAH GURU</a>
              </div>

                  @if(session('pesan'))
                  <div class="alert alert-success alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  <h4><i class="icon fa fa-check"></i>Success!</h4>
                  {{ session('pesan') }}.                  
                  </div>
                  @endif


              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class=" text-primary">
                    <tr align="center">
                      <th>No</th>
                      <th>NAMA</th>
                      <th>NIP</th>
                      <th>MATA PELAJARAN</th>
                      <th>ALAMAT</th>
                      <th>FOTO</th>
                      <th colspan="2">ACTION</th>  
                    </tr>
                    </thead>
                    <tbody>
                    <?php $i = 1; ?>
                    @foreach ($guru as $g)
                          <tr align="center">
                              <td align="center"><?php echo $i; ?></td>
                              <td>{{$g->nama_guru}}</td>
                              <td>{{$g->nip}}</td>
                              <td>{{$g->mapel}}</td>
                              <td>{{$g->alamat}}</td>
                              <td><img src="{{ url('foto_guru/' .$g->foto) }}" width="100px" alt=""></td>
                              <td>
                              <a class="btn btn-success"  href="/guru/detail/{{$g->id_guru}}">DETAIL</a>
                              <a class="btn btn-warning"  href="/guru/edit/{{$g->id_guru}}">EDIT</a>
                              <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#delete{{$g->id_guru}}">
                                  Delete
                              </button>
                              </td>
                          </tr>
                          <?php $i++; ?>
                          @endforeach
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

        @foreach ($guru as $g)
        <div class="modal fade" id="delete{{$g->id_guru}}">
        <div class="modal-dialog modal-sm">
          <div class="modal-content bg-danger">
            <div class="modal-header">
              <h4 class="modal-title">{{$g->nama_guru}}</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <p>Apakah Anda Yakin Mengahapus Data Ini?</p>
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-outline-light" data-dismiss="modal">Batal</button>
              <a href="/guru/delete/{{ $g->id_guru }}" class="btn btn-outline-light">Ya, Delete</a>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      @endforeach

@endsection