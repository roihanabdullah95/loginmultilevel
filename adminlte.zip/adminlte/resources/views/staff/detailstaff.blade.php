@extends('layouts.master')
@section('title','Detail staff')


@section('content')

<table class="table">
    <tr>
        <th width="150px">Nama</th>
        <th width="30px">:</th>
        <th>{{ $staff->nama_staff }}</th>
    </tr>
    <tr>
        <th width="150px">NIP</th>
        <th width="30px">:</th>
        <th>{{ $staff->nip }}</th>
    </tr>
    <tr>
        <th width="150px">Bagian</th>
        <th width="30px">:</th>
        <th>{{ $staff->bagian }}</th>
    </tr>
    <tr>
        <th width="150px">Alamat</th>
        <th width="30px">:</th>
        <th>{{ $staff->alamat }}</th>
    </tr>
    <tr>
        <th width="150px">Foto</th>
        <th width="30px">:</th>
        <th><img src="{{ url('foto_staff/'.$staff->foto) }}" width="200px"></th>
    </tr>
    <tr>
        <th><a href="/staff" class="btn btn-success tbn-sm">Kembali</a></th>
    </tr>
    

</table>

@endsection