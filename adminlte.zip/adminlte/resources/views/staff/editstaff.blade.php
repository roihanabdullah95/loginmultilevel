@extends('layouts.master')
@section('title','Edit Database Staff')


@section('content')

<form action="/staff/update/{{ $staff->id_staff }}" method="POST" enctype="multipart/form-data">
    @csrf

    <div class="content">
        <div class="row">
            <div class="col-md-8 offset-sm-2">

    <div class="form-group">
        <label>Nama Staff</label>
        <input name='nama_staff' class="form-control" value="{{ $staff->nama_staff }}"> 
        <div class="text-danger">
            @error('nama_staff')
                {{ $message }}
            @enderror
        </div>
    </div>

    <div class="form-group">
        <label>NIP</label>
        <input name='nip' class="form-control" value="{{ ($staff->nip) }}">
        <div class="text-danger">
            @error('nip')
                {{ $message }}
            @enderror
        </div>
    </div>

    <div class="form-group">
        <label>Bagian</label>
        <input name='bagian' class="form-control" value="{{ ($staff->bagian) }}">
        <div class="text-danger">
            @error('bagian')
                {{ $message }}
            @enderror
        </div>
    </div>

    <div class="form-group">
        <label>Alamat</label>
        <input name='alamat' class="form-control" value="{{ ($staff->alamat) }}">
        <div class="text-danger">
            @error('alamat')
                {{ $message }}
            @enderror
        </div>
    </div>

    <div class="col-sm 12">
        <div class="col-sm-6">
            <img src="{{ url('foto_staff/'.$staff->foto) }}" width="100px">
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <label>Foto staff</label>
                <input type='file' name='foto' class="form-control">
                <div class="text-danger">
                @error('foto')
                    {{ $message }}
                @enderror
                </div>
            </div>
        </div>
    </div>

    <div class="form-group">
        <button class="btn btn-primary btn-sm">Simpan</button>
        <a href="/staff" class="btn btn-success btn-sm">Kembali</a>
    </div>
    
            </div>
        </div>
    </div>

</form>

@endsection