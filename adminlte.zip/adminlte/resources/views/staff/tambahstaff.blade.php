@extends('layouts.master')
@section('title','Tambah Staff')


@section('content')

<form action="/staff/insert" method="POST" enctype="multipart/form-data">
    @csrf

    <div class="content">
        <div class="row">
            <div class="col-md-8 offset-sm-2">

    <div class="form-group">
        <label>Nama staff</label>
        <input name='nama_staff' class="form-control" value="{{ old('nama_staff') }}"> 
        <div class="text-danger">
            @error('nama_staff')
                {{ $message }}
            @enderror
        </div>
    </div>

    <div class="form-group">
        <label>NIP</label>
        <input name='nip' class="form-control" value="{{ old('nip') }}">
        <div class="text-danger">
            @error('nip')
                {{ $message }}
            @enderror
        </div>
    </div>

    <div class="form-group">
        <label>Bagian</label>
        <input name='bagian' class="form-control" value="{{ old('bagian') }}">
        <div class="text-danger">
            @error('bagian')
                {{ $message }}
            @enderror
        </div>
    </div>

    <div class="form-group">
        <label>Alamat</label>
        <input name='alamat' class="form-control" value="{{ old('alamat') }}">
        <div class="text-danger">
            @error('alamat')
                {{ $message }}
            @enderror
        </div>
    </div>

    <div class="form-group">
        <label>Foto</label>
        <input type='file' name='foto' class="form-control" value="{{ old('foto') }}">
        <div class="text-danger">
            @error('foto')
                {{ $message }}
            @enderror
        </div>
    </div>

    <div class="form-group">
        <button class="btn btn-primary btn-sm">Simpan</button>
        <a href="/staff" class="btn btn-success btn-sm">Kembali</a>
    </div>
    
            </div>
        </div>
    </div>

</form>


@endsection