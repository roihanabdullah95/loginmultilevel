@extends('layouts.master')
@section('title','DATABASE STAFF')

@section('content')

<div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <a href="/staff/tambah" class="btn btn-warning mb-1">TAMBAH STAFF</a>
              </div>

                  @if(session()->get('success'))
                  <div class="alert alert-success alert-dismissible fade show" role="alert">
                  <strong>{{ session()->get('success')}}</strong> 
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
                  </div>
                  @endif


              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class=" text-primary">
                    <tr align="center">
                      <th>No</th>
                      <th>NAMA</th>
                      <th>NIP</th>
                      <th>BAGIAN</th>
                      <th>ALAMAT</th>
                      <th>FOTO</th>
                      <th colspan="2">ACTION</th>  
                    </tr>
                    </thead>
                    <tbody>
                    <?php $i = 1; ?>
                    @foreach ($staff as $st)
                          <tr alisn="center">
                              <td align="center"><?php echo $i; ?></td>
                              <td>{{$st->nama_staff}}</td>
                              <td>{{$st->nip}}</td>
                              <td>{{$st->bagian}}</td>
                              <td>{{$st->alamat}}</td>
                              <td><img src="{{ url('foto_staff/' .$st->foto) }}" width="100px" alt=""></td>
                              <td>
                              <a class="btn btn-success"  href="/staff/detail/{{$st->id_staff}}">DETAIL</a>
                              <a class="btn btn-warning"  href="/staff/edit/{{$st->id_staff}}">EDIT</a>
                              <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#delete{{$st->id_staff}}">
                                  Delete
                              </button>
                              </td>
                          </tr>
                          <?php $i++; ?>
                          @endforeach
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

          @foreach ($staff as $st)
        <div class="modal fade" id="delete{{$st->id_staff}}">
        <div class="modal-dialog modal-sm">
          <div class="modal-content bg-danger">
            <div class="modal-header">
              <h4 class="modal-title">{{$st->nama_staff}}</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <p>Apakah Anda Yakin Mengahapus Data Ini?</p>
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-outline-light" data-dismiss="modal">Batal</button>
              <a href="/staff/delete/{{ $st->id_staff }}" class="btn btn-outline-light">Ya, Delete</a>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      @endforeach
@endsection