<nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
        <!-- <li class="header">MAIN NAVIGATION</li>        -->
        <li class="{{ request()->is('/') ? 'active' : '' }}">
            <a href="/" class="nav-link">
              <i class="nav-icon fas fa-home"></i>
              <p>Home</p>
            </a>
        </li>
        @if(auth()->user()->level==1)
        <li class="{{ request()->is('/guru') ? 'active' : '' }}">
            <a href="/guru" class="nav-link">
              <i class="nav-icon fas fa-user"></i>
              <p>Guru</p>
            </a>
          </li>

          <li class="{{ request()->is('/siswa') ? 'active' : '' }}">
            <a href="/siswa" class="nav-link">
              <i class="nav-icon fas fa-users"></i>
              <p>Siswa</p>
            </a>
          </li>
         
        <li class="{{ request()->is('/staff') ? 'active' : '' }}">
          <!-- <li class="{{ 'dashboard' == request()->path() ? 'active' : ''  }}"> -->
            <a href="/staff" class="nav-link">
              <i class="nav-icon fas fa-book"></i>
              <p>Staff</p>
            </a>
          </li>
        
          
          @elseif(auth()->user()->level==2)
          <li class="{{ request()->is('/guru') ? 'active' : '' }}">
            <a href="/guru" class="nav-link">
              <i class="nav-icon fas fa-user"></i>
              <p>Guru</p>
            </a>
          </li>

          @elseif(auth()->user()->level==3)
          <li class="{{ request()->is('/siswa') ? 'active' : '' }}">
            <a href="/siswa" class="nav-link">
              <i class="nav-icon fas fa-users"></i>
              <p>Siswa</p>
            </a>
          </li>
        @endif      
        </li>         
        </ul>
      </nav>