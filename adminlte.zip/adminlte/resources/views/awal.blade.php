@extends('layouts.master')
@section('title','Home')

@section('content')

    <h1>Selamat Datang Admin SMK EXCELLENT SEMARANG</h1>

@endsection