@extends('layouts.master')
@section('title','Detail User')


@section('content')
<div class="modal fade" id="detail">
        <div class="modal-dialog modal-md">
          <div class="modal-content bg-danger">
            <div class="modal-header">
              <h4 class="modal-title"></h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
            <div class="avatar">
              <i class="fa fa-user" style="font-size: 50px; color:white;"></i>
            </div>
             
          <table class="table">
            <tr>
              <th width="150px">Nama</th>
              <th width="30px">:</th>
              <th>{{ Auth::user()->name }}</th>
            </tr>
            <tr>
              <th width="150px">Email</th>
              <th width="30px">:</th>
              <th>{{ Auth::user()->email }}</th>
             </tr>
          </table>
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-outline-light" data-dismiss="modal">Kembali</button>
              <a href="/user/edit/{{$data->id}}" class="btn btn-outline-light">Edit Profile</a>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>


@endsection