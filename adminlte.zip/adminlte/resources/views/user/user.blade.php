@extends('layouts.master')
@section('title', 'DATA PROFILE')

@section('content')
    <div class="card mb-3" style="max-width: 540px;">
        <div class="row g-0">
            <div class="col-md-4">
                {{-- <img src="..." alt="..." width="200px"> --}}
                <i class="fa fa-user" width="50%"></i>
            </div>
            <div class="col-md-8">
                <div class="card-header">
                    <h5 class="card-title">{{ Auth::user()->name }}</h5>
                </div>
                <table class="table">
                    <tbody>
                        <tr>
                            <th width="100px">EMAIL</th>
                            <th width="30px">:</th>
                            <th>{{ Auth::user()->email }}</th>
                        </tr>
                    </tbody>
                </table>
            </div>
            <a class="btn btn-warning" href="">EDIT</a>
            <a href="/home" class="btn btn-success mt-3 tbn-sm">Kembali</a>
        </div>
    </div>



@endsection
