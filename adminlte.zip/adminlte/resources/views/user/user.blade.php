@extends('layouts.master')
@section('title','DATA PROFILE')

@section('content')

<div class="card-body">
    <div class="table-responsive">
      <table class="table">
        <thead class=" text-primary">
        <tr align="center">
                <th width="150px">Nama</th>
                <th width="30px">:</th>
                <th>{{ $data->name }}</th>
        </tr>
        </thead>
        </table>
    </div>
</div>
@endsection