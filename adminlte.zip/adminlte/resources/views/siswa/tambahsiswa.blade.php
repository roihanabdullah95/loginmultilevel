@extends('layouts.master')
@section('title','Tambah Siswa')


@section('content')

<form action="/siswa/insert" method="POST" enctype="multipart/form-data">
    @csrf

    <div class="content">
        <div class="row">
            <div class="col-md-8 offset-sm-2">

    <div class="form-group">
        <label>Nama Siswa</label>
        <input name='nama_siswa' class="form-control" value="{{ old('nama_siswa') }}"> 
        <div class="text-danger">
            @error('nama_siswa')
                {{ $message }}
            @enderror
        </div>
    </div>

    <div class="form-group">
        <label>NIP</label>
        <input name='nis' class="form-control" value="{{ old('nis') }}">
        <div class="text-danger">
            @error('nis')
                {{ $message }}
            @enderror
        </div>
    </div>

    <div class="form-group">
        <label>EMAIL</label>
        <input name='email' class="form-control" value="{{ old('email') }}">
        <div class="text-danger">
            @error('email')
                {{ $message }}
            @enderror
        </div>
    </div>

    <div class="form-group">
        <label>Alamat</label>
        <input name='alamat' class="form-control" value="{{ old('alamat') }}">
        <div class="text-danger">
            @error('alamat')
                {{ $message }}
            @enderror
        </div>
    </div>

    <div class="form-group">
        <label>Foto</label>
        <input type='file' name='foto' class="form-control" value="{{ old('foto') }}">
        <div class="text-danger">
            @error('foto')
                {{ $message }}
            @enderror
        </div>
    </div>

    <div class="form-group">
        <button class="btn btn-primary btn-sm">Simpan</button>
        <a href="/siswa" class="btn btn-success btn-sm">Kembali</a>
    </div>
    
            </div>
        </div>
    </div>

</form>


@endsection