@extends('layouts.master')
@section('title','Detail Siswa')


@section('content')

<table class="table">
    <tr>
        <th width="150px">Nama</th>
        <th width="30px">:</th>
        <th>{{ $siswa->nama_siswa }}</th>
    </tr>
    <tr>
        <th width="150px">NIS</th>
        <th width="30px">:</th>
        <th>{{ $siswa->nis }}</th>
    </tr>
    <tr>
        <th width="150px">Email</th>
        <th width="30px">:</th>
        <th>{{ $siswa->email }}</th>
    </tr>
    <tr>
        <th width="150px">Alamat</th>
        <th width="30px">:</th>
        <th>{{ $siswa->alamat }}</th>
    </tr>
    <tr>
        <th width="150px">Foto</th>
        <th width="30px">:</th>
        <th><img src="{{ url('foto_siswa/'.$siswa->foto) }}" width="200px"></th>
    </tr>
    <tr>
        <th><a href="/siswa" class="btn btn-success tbn-sm">Kembali</a></th>
    </tr>
    

</table>






@endsection