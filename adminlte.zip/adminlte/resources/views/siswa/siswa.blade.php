@extends('layouts.master')
@section('title','DATABASE SISWA')

@section('content')

<div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <a href="/siswa/tambah" class="btn btn-warning mb-1">TAMBAH SISWA</a>
              </div>

                @if(session('pesan'))
                  <div class="alert alert-success alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  <h4><i class="icon fa fa-check"></i>Success!</h4>
                  {{ session('pesan') }}.                  
                  </div>
                  @endif


              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class=" text-primary">
                    <tr align="center">
                      <th>No</th>
                      <th>NAMA</th>
                      <th>NIS</th>
                      <th>EMAIL</th>
                      <th>ALAMAT</th>
                      <th>FOTO</th>
                      <th colspan="2">ACTION</th>  
                    </tr>
                    </thead>
                    <tbody>
                    <?php $i = 1; ?>
                    @foreach ($siswa as $s)
                          <tr alisn="center">
                              <td align="center"><?php echo $i; ?></td>
                              <td>{{$s->nama_siswa}}</td>
                              <td>{{$s->nis}}</td>
                              <td>{{$s->email}}</td>
                              <td>{{$s->alamat}}</td>
                              <td><img src="{{ url('foto_siswa/' .$s->foto) }}" width="100px" alt=""></td>
                              <td>
                              <a class="btn btn-success"  href="/siswa/detail/{{$s->id_siswa}}">DETAIL</a>
                              <a class="btn btn-warning"  href="/siswa/edit/{{$s->id_siswa}}">EDIT</a>
                              <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#delete{{$s->id_siswa}}">
                                  Delete
                              </button>
                              </td>
                          </tr>
                          <?php $i++; ?>
                          @endforeach
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

          @foreach ($siswa as $s)
        <div class="modal fade" id="delete{{$s->id_siswa}}">
        <div class="modal-dialog modal-sm">
          <div class="modal-content bg-danger">
            <div class="modal-header">
              <h4 class="modal-title">{{$s->nama_siswa}}</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <p>Apakah Anda Yakin Mengahapus Data Ini?</p>
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-outline-light" data-dismiss="modal">Batal</button>
              <a href="/siswa/delete/{{ $s->id_siswa }}" class="btn btn-outline-light">Ya, Delete</a>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      @endforeach
@endsection