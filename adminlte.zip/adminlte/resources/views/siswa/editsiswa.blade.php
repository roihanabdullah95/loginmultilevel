@extends('layouts.master')
@section('title','Edit Database Siswa')


@section('content')

<form action="/siswa/update/{{ $siswa->id_siswa }}" method="POST" enctype="multipart/form-data">
    @csrf

    <div class="content">
        <div class="row">
            <div class="col-md-8 offset-sm-2">

    <div class="form-group">
        <label>Nama Siswa</label>
        <input name='nama_siswa' class="form-control" value="{{ $siswa->nama_siswa }}"> 
        <div class="text-danger">
            @error('nama_siswa')
                {{ $message }}
            @enderror
        </div>
    </div>

    <div class="form-group">
        <label>NIS</label>
        <input name='nis' class="form-control" value="{{ ($siswa->nis) }}">
        <div class="text-danger">
            @error('nis')
                {{ $message }}
            @enderror
        </div>
    </div>

    <div class="form-group">
        <label>Email</label>
        <input name='email' class="form-control" value="{{ ($siswa->email) }}">
        <div class="text-danger">
            @error('email')
                {{ $message }}
            @enderror
        </div>
    </div>

    <div class="form-group">
        <label>Alamat</label>
        <input name='alamat' class="form-control" value="{{ ($siswa->alamat) }}">
        <div class="text-danger">
            @error('alamat')
                {{ $message }}
            @enderror
        </div>
    </div>

    <div class="col-sm 12">
        <div class="col-sm-6">
            <img src="{{ url('foto_siswa/'.$siswa->foto) }}" width="100px">
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <label>Foto siswa</label>
                <input type='file' name='foto' class="form-control">
                <div class="text-danger">
                @error('foto')
                    {{ $message }}
                @enderror
                </div>
            </div>
        </div>
    </div>

    <div class="form-group">
        <button class="btn btn-primary btn-sm">Simpan</button>
        <a href="/siswa" class="btn btn-success btn-sm">Kembali</a>
    </div>
    
            </div>
        </div>
    </div>

</form>

@endsection