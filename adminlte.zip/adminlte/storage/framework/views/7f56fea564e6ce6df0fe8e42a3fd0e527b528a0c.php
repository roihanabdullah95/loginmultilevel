
<?php $__env->startSection('title','DATABASE STAFF'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <a href="/staff/tambah" class="btn btn-warning mb-1">TAMBAH STAFF</a>
              </div>

                  <?php if(session()->get('success')): ?>
                  <div class="alert alert-success alert-dismissible fade show" role="alert">
                  <strong><?php echo e(session()->get('success')); ?></strong> 
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
                  </div>
                  <?php endif; ?>


              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class=" text-primary">
                    <tr align="center">
                      <th>No</th>
                      <th>NAMA</th>
                      <th>NIP</th>
                      <th>BAGIAN</th>
                      <th>ALAMAT</th>
                      <th>FOTO</th>
                      <th colspan="2">ACTION</th>  
                    </tr>
                    </thead>
                    <tbody>
                    <?php $i = 1; ?>
                    <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr alisn="center">
                              <td align="center"><?php echo $i; ?></td>
                              <td><?php echo e($st->nama_staff); ?></td>
                              <td><?php echo e($st->nip); ?></td>
                              <td><?php echo e($st->bagian); ?></td>
                              <td><?php echo e($st->alamat); ?></td>
                              <td><img src="<?php echo e(url('foto_staff/' .$st->foto)); ?>" width="100px" alt=""></td>
                              <td>
                              <a class="btn btn-success"  href="/staff/detail/<?php echo e($st->id_staff); ?>">DETAIL</a>
                              <a class="btn btn-warning"  href="/staff/edit/<?php echo e($st->id_staff); ?>">EDIT</a>
                              <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#delete<?php echo e($st->id_staff); ?>">
                                  Delete
                              </button>
                              </td>
                          </tr>
                          <?php $i++; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

          <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="delete<?php echo e($st->id_staff); ?>">
        <div class="modal-dialog modal-sm">
          <div class="modal-content bg-danger">
            <div class="modal-header">
              <h4 class="modal-title"><?php echo e($st->nama_staff); ?></h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <p>Apakah Anda Yakin Mengahapus Data Ini?</p>
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-outline-light" data-dismiss="modal">Batal</button>
              <a href="/staff/delete/<?php echo e($st->id_staff); ?>" class="btn btn-outline-light">Ya, Delete</a>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adminlte\resources\views/staff/staff.blade.php ENDPATH**/ ?>