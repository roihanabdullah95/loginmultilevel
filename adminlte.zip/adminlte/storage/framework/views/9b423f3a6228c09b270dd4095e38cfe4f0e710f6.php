
<?php $__env->startSection('title','Home'); ?>

<?php $__env->startSection('content'); ?>

    <h1>Selamat Datang Admin SMK EXCELLENT SEMARANG</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adminlte\resources\views/awal.blade.php ENDPATH**/ ?>