<nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
        <!-- <li class="header">MAIN NAVIGATION</li>        -->
        <li class="<?php echo e(request()->is('/') ? 'active' : ''); ?>">
            <a href="/" class="nav-link">
              <i class="nav-icon fas fa-home"></i>
              <p>Home</p>
            </a>
        </li>
        <?php if(auth()->user()->level==1): ?>
        <li class="<?php echo e(request()->is('/guru') ? 'active' : ''); ?>">
            <a href="/guru" class="nav-link">
              <i class="nav-icon fas fa-user"></i>
              <p>Guru</p>
            </a>
          </li>

          <li class="<?php echo e(request()->is('/siswa') ? 'active' : ''); ?>">
            <a href="/siswa" class="nav-link">
              <i class="nav-icon fas fa-users"></i>
              <p>Siswa</p>
            </a>
          </li>
         
        <li class="<?php echo e(request()->is('/staff') ? 'active' : ''); ?>">
          <!-- <li class="<?php echo e('dashboard' == request()->path() ? 'active' : ''); ?>"> -->
            <a href="/staff" class="nav-link">
              <i class="nav-icon fas fa-book"></i>
              <p>Staff</p>
            </a>
          </li>
        
          
          <?php elseif(auth()->user()->level==2): ?>
          <li class="<?php echo e(request()->is('/guru') ? 'active' : ''); ?>">
            <a href="/guru" class="nav-link">
              <i class="nav-icon fas fa-user"></i>
              <p>Guru</p>
            </a>
          </li>

          <?php elseif(auth()->user()->level==3): ?>
          <li class="<?php echo e(request()->is('/siswa') ? 'active' : ''); ?>">
            <a href="/siswa" class="nav-link">
              <i class="nav-icon fas fa-users"></i>
              <p>Siswa</p>
            </a>
          </li>
        <?php endif; ?>      
        </li>         
        </ul>
      </nav><?php /**PATH C:\xampp\htdocs\adminlte\resources\views/layouts/nav.blade.php ENDPATH**/ ?>