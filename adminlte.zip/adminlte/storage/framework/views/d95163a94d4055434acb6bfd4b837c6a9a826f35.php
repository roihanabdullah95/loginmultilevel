
<?php $__env->startSection('title','Detail Guru'); ?>


<?php $__env->startSection('content'); ?>

<table class="table">
    <tr>
        <th>Nama</th>
        <th>:</th>
        <th><?php echo e($guru->nama_guru); ?></th>
    </tr>
    <tr>
    <th>NIP</th>
        <th>Mata Pelajaran</th>
        <th>Alamat</th>
        <th>Foto</th>
    </tr>

</table>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adminlte\resources\views/detailguru.blade.php ENDPATH**/ ?>