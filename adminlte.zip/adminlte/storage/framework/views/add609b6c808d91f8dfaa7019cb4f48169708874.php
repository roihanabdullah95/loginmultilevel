
<?php $__env->startSection('title','DATA PROFILE'); ?>

<?php $__env->startSection('content'); ?>

<div class="card-body">
    <div class="table-responsive">
      <table class="table">
        <thead class=" text-primary">
        <tr align="center">
                <th width="150px">Nama</th>
                <th width="30px">:</th>
                <th><?php echo e($data->name); ?></th>
        </tr>
        </thead>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adminlte\resources\views/user/user.blade.php ENDPATH**/ ?>