
<?php $__env->startSection('title', 'DATA PROFILE'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card mb-3" style="max-width: 540px;">
        <div class="row g-0">
            <div class="col-md-4">
                
                <i class="fa fa-user" width="50%"></i>
            </div>
            <div class="col-md-8">
                <div class="card-header">
                    <h5 class="card-title"><?php echo e(Auth::user()->name); ?></h5>
                </div>
                <table class="table">
                    <tbody>
                        <tr>
                            <th width="100px">EMAIL</th>
                            <th width="30px">:</th>
                            <th><?php echo e(Auth::user()->email); ?></th>
                        </tr>
                    </tbody>
                </table>
            </div>
            <a class="btn btn-warning" href="">EDIT</a>
            <a href="/home" class="btn btn-success mt-3 tbn-sm">Kembali</a>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adminlte\resources\views/user/user.blade.php ENDPATH**/ ?>