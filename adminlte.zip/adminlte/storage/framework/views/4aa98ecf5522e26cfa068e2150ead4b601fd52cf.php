
<?php $__env->startSection('title','Detail staff'); ?>


<?php $__env->startSection('content'); ?>

<table class="table">
    <tr>
        <th width="150px">Nama</th>
        <th width="30px">:</th>
        <th><?php echo e($staff->nama_staff); ?></th>
    </tr>
    <tr>
        <th width="150px">NIP</th>
        <th width="30px">:</th>
        <th><?php echo e($staff->nip); ?></th>
    </tr>
    <tr>
        <th width="150px">Bagian</th>
        <th width="30px">:</th>
        <th><?php echo e($staff->bagian); ?></th>
    </tr>
    <tr>
        <th width="150px">Alamat</th>
        <th width="30px">:</th>
        <th><?php echo e($staff->alamat); ?></th>
    </tr>
    <tr>
        <th width="150px">Foto</th>
        <th width="30px">:</th>
        <th><img src="<?php echo e(url('foto_staff/'.$staff->foto)); ?>" width="200px"></th>
    </tr>
    <tr>
        <th><a href="/staff" class="btn btn-success tbn-sm">Kembali</a></th>
    </tr>
    

</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adminlte\resources\views/staff/detailstaff.blade.php ENDPATH**/ ?>