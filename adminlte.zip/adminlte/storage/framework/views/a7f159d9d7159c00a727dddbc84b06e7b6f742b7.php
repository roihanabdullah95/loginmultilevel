
<?php $__env->startSection('title','Edit Database Staff'); ?>


<?php $__env->startSection('content'); ?>

<form action="/staff/update/<?php echo e($staff->id_staff); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    <div class="content">
        <div class="row">
            <div class="col-md-8 offset-sm-2">

    <div class="form-group">
        <label>Nama Staff</label>
        <input name='nama_staff' class="form-control" value="<?php echo e($staff->nama_staff); ?>"> 
        <div class="text-danger">
            <?php $__errorArgs = ['nama_staff'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="form-group">
        <label>NIP</label>
        <input name='nip' class="form-control" value="<?php echo e(($staff->nip)); ?>">
        <div class="text-danger">
            <?php $__errorArgs = ['nip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="form-group">
        <label>Bagian</label>
        <input name='bagian' class="form-control" value="<?php echo e(($staff->bagian)); ?>">
        <div class="text-danger">
            <?php $__errorArgs = ['bagian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="form-group">
        <label>Alamat</label>
        <input name='alamat' class="form-control" value="<?php echo e(($staff->alamat)); ?>">
        <div class="text-danger">
            <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-sm 12">
        <div class="col-sm-6">
            <img src="<?php echo e(url('foto_staff/'.$staff->foto)); ?>" width="100px">
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <label>Foto staff</label>
                <input type='file' name='foto' class="form-control">
                <div class="text-danger">
                <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>
    </div>

    <div class="form-group">
        <button class="btn btn-primary btn-sm">Simpan</button>
        <a href="/staff" class="btn btn-success btn-sm">Kembali</a>
    </div>
    
            </div>
        </div>
    </div>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adminlte\resources\views/staff/editstaff.blade.php ENDPATH**/ ?>