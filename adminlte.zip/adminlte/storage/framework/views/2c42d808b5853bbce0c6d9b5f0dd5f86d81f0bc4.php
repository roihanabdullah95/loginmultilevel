<footer class="main-footer">
    <strong>Copyright &copy; 2021 <a href="google.com">AdminSMK.id</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 3.1.0
    </div>
  </footer><?php /**PATH C:\xampp\htdocs\adminlte\resources\views/layouts/footer.blade.php ENDPATH**/ ?>