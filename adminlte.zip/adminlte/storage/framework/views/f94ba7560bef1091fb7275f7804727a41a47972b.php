
<?php $__env->startSection('title','DATABASE GURU'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <a href="/guru/tambah" class="btn btn-warning mb-1">TAMBAH GURU</a>
              </div>

                  <?php if(session('pesan')): ?>
                  <div class="alert alert-success alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  <h4><i class="icon fa fa-check"></i>Success!</h4>
                  <?php echo e(session('pesan')); ?>.                  
                  </div>
                  <?php endif; ?>


              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class=" text-primary">
                    <tr align="center">
                      <th>No</th>
                      <th>NAMA</th>
                      <th>NIP</th>
                      <th>MATA PELAJARAN</th>
                      <th>ALAMAT</th>
                      <th>FOTO</th>
                      <th colspan="2">ACTION</th>  
                    </tr>
                    </thead>
                    <tbody>
                    <?php $i = 1; ?>
                    <?php $__currentLoopData = $guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr align="center">
                              <td align="center"><?php echo $i; ?></td>
                              <td><?php echo e($g->nama_guru); ?></td>
                              <td><?php echo e($g->nip); ?></td>
                              <td><?php echo e($g->mapel); ?></td>
                              <td><?php echo e($g->alamat); ?></td>
                              <td><img src="<?php echo e(url('foto_guru/' .$g->foto)); ?>" width="100px" alt=""></td>
                              <td>
                              <a class="btn btn-success"  href="/guru/detail/<?php echo e($g->id_guru); ?>">DETAIL</a>
                              <a class="btn btn-warning"  href="/guru/edit/<?php echo e($g->id_guru); ?>">EDIT</a>
                              <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#delete<?php echo e($g->id_guru); ?>">
                                  Delete
                              </button>
                              </td>
                          </tr>
                          <?php $i++; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

        <?php $__currentLoopData = $guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="delete<?php echo e($g->id_guru); ?>">
        <div class="modal-dialog modal-sm">
          <div class="modal-content bg-danger">
            <div class="modal-header">
              <h4 class="modal-title"><?php echo e($g->nama_guru); ?></h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <p>Apakah Anda Yakin Mengahapus Data Ini?</p>
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-outline-light" data-dismiss="modal">Batal</button>
              <a href="/guru/delete/<?php echo e($g->id_guru); ?>" class="btn btn-outline-light">Ya, Delete</a>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adminlte\resources\views/guru/guru.blade.php ENDPATH**/ ?>