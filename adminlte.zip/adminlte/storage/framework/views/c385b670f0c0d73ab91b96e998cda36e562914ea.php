
<?php $__env->startSection('title','Detail Siswa'); ?>


<?php $__env->startSection('content'); ?>

<table class="table">
    <tr>
        <th width="150px">Nama</th>
        <th width="30px">:</th>
        <th><?php echo e($siswa->nama_siswa); ?></th>
    </tr>
    <tr>
        <th width="150px">NIS</th>
        <th width="30px">:</th>
        <th><?php echo e($siswa->nis); ?></th>
    </tr>
    <tr>
        <th width="150px">Email</th>
        <th width="30px">:</th>
        <th><?php echo e($siswa->email); ?></th>
    </tr>
    <tr>
        <th width="150px">Alamat</th>
        <th width="30px">:</th>
        <th><?php echo e($siswa->alamat); ?></th>
    </tr>
    <tr>
        <th width="150px">Foto</th>
        <th width="30px">:</th>
        <th><img src="<?php echo e(url('foto_siswa/'.$siswa->foto)); ?>" width="200px"></th>
    </tr>
    <tr>
        <th><a href="/siswa" class="btn btn-success tbn-sm">Kembali</a></th>
    </tr>
    

</table>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adminlte\resources\views/siswa/detailsiswa.blade.php ENDPATH**/ ?>