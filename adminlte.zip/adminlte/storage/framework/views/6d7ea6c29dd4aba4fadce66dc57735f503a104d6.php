
<?php $__env->startSection('title','DATABASE GURU'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <a href="#" class="btn btn-warning mb-1">TAMBAH GURU</a>
              </div>

                  <?php if(session()->get('success')): ?>
                  <div class="alert alert-success alert-dismissible fade show" role="alert">
                  <strong><?php echo e(session()->get('success')); ?></strong> 
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
                  </div>
                  <?php endif; ?>


              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class=" text-primary">
                    <tr align="center">
                      <th>No</th>
                      <th>NAMA</th>
                      <th>NIP</th>
                      <th>MATA PELAJARAN</th>
                      <th>ALAMAT</th>
                      <th>FOTO</th>
                      <th colspan="2">ACTION</th>  
                    </tr>
                    </thead>
                    <tbody>
                    <?php $i = 1; ?>
                    <?php $__currentLoopData = $guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr align="center">
                              <td align="center"><?php echo $i; ?></td>
                              <td><?php echo e($g->nama_guru); ?></td>
                              <td><?php echo e($g->nip); ?></td>
                              <td><?php echo e($g->mapel); ?></td>
                              <td><?php echo e($g->alamat); ?></td>
                              <td><img src="<?php echo e(url('foto_guru/' .$g->foto)); ?>" width="100px" alt=""></td>
                              <td>
                              <a class="btn btn-success"  href="#">DETAIL</a>
                              <a class="btn btn-warning"  href="#">EDIT</a>
                              <a class="btn btn-danger"  href="#">DELETE</a>                        
                              </td>
                          </tr>
                          <?php $i++; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adminlte\resources\views/guru.blade.php ENDPATH**/ ?>