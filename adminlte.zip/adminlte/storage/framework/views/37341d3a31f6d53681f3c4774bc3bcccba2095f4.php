
<?php $__env->startSection('title','User'); ?>

<?php $__env->startSection('content'); ?>

    <h1>Selamat Datang User SMK EXCELLENT SEMARANG</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adminlte\resources\views/layouts/user.blade.php ENDPATH**/ ?>