<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class StaffModel extends Model
{
    public function allData()
    {
    return DB::table('staff')->get();
    }
    
    public function detailData($id_staff)
    {
        return DB::table('staff')->where('id_staff', $id_staff)->first();
    }

    public function tambahData($data)
    {
        DB::table('staff')->insert($data);
    }

    public function editData($id_staff, $data)
    {
        DB::table('staff')
            ->where('id_staff',$id_staff)
            ->update($data);
    }

    public function deleteData($id_staff)
    {
        DB::table('staff')
            ->where('id_staff',$id_staff)
            ->delete();
    }
}
