<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\UserModel;

class UserController extends Controller
{
    public function __construct()
    {
        $this->UserModel = new UserModel();
        $this->middleware('auth');
    }

    public function index()
    {
        $data = [
            'user' => $this->UserModel->allData(),
        ];
        // view('user') adalah file user.blade.php
        return view('user/user', $data);
        // return view('');
    }

    public function detail($id)
    {
        $data = [
            'user' => $this->UserModel->detailData($id),
        ];
        return view('user/user',$data);
    }
}
