<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\StaffModel;

class StaffController extends Controller
{
    public function __construct()
    {
        $this->StaffModel = new StaffModel();
        $this->middleware('auth');
    }

    public function index()
    {
        $data = [
            'staff' => $this->StaffModel->allData(),
        ];
        // view('staff') adalah file staff.blade.php
        return view('staff/staff', $data);
    }

    public function detail($id_staff)
    {
        if (!$this->StaffModel->detailData($id_staff))
        {
            abort(404);
        }
        $data = [
            'staff' => $this->StaffModel->detailData($id_staff),
        ];
        // view('staff') adalah file staff.blade.php
        return view('staff/detailstaff', $data);
    }

    public function tambah()
    {
        // view('staff/tambahstaff') adalah file tambahstaff.blade.php yang ada di folder staff
        return view('staff/tambahstaff');
    }

    public function insert()
    {
        // Jika ada data kosong saat Tambah
        Request()->validate([
            'nama_staff'=>'required',
            'nip'=>'required|unique:staff,nip|min:4|max:11',
            'bagian'=>'required',
            'alamat'=>'required',
            'foto'=>'required|mimes:jpg,jpeg,bmp,png|max:1024',
        ],[
            // variable yg ada di table localhost/phpmyadmin
            'nama_staff.required' => 'Wajib diisi !!',
            'nip.required' => 'Wajib diisi !!',
            'nip.unique' => 'NIP ini sudah ada !!',
            'nip.min' => 'Min. 4 Karakter !!',
            'nip.max' => 'Max. 11 Karakter !!',
            'bagian.required' => 'Wajib diisi !!',
            'alamat.required' => 'Wajib diisi !!',
            'foto.required' => 'Wajib diisi !!',

        ]);

        // upload foto
        $file = Request()->foto; //foto adalah data tabel yg ada di localhost/phpmyadmin tabel foto
        $fileName = Request()->nip . '.' . $file->extension();
        $file->move(public_path('foto_staff'), $fileName); //foto_staff adalah nama folder yg ada di public foto_staff

        $data = [
            'nama_staff' => Request()->nama_staff,
            'nip' => Request()->nip,
            'bagian' => Request()->bagian,
            'alamat' => Request()->alamat,
            'foto' => $fileName, //foto adalah data tabel yg ada di localhost/phpmyadmin tabel foto
        ];

        $this->StaffModel->tambahData($data);
        return redirect()->route('staff')->with('pesan', 'Data Berhasil Ditambahkan !!!'); // 'staff' adalah halaman staff
    }

    public function edit($id_staff)
    {
        if (!$this->StaffModel->detailData($id_staff))
        {
            abort(404);
        }
        $data = [
            'staff' => $this->StaffModel->detailData($id_staff),
        ];
        // view('staff/tambahstaff') adalah file tambahstaff.blade.php yang ada di folder staff
        return view('staff/editstaff', $data);
    }

    public function update($id_staff)
    {
        // Jika ada data kosong saat Tambah
        Request()->validate([
            'nama_staff'=>'required',
            'nip'=>'required|min:4|max:11',
            'bagian'=>'required',
            'alamat'=>'required',
            'foto'=>'mimes:jpg,jpeg,bmp,png|max:1024',
        ],[
            // variable yg ada di table localhost/phpmyadmin
            'nama_staff.required' => 'Wajib diisi !!',
            'nip.required' => 'Wajib diisi !!',
            'nip.min' => 'Min. 4 Karakter !!',
            'nip.max' => 'Max. 11 Karakter !!',
            'bagian.required' => 'Wajib diisi !!',
            'alamat.required' => 'Wajib diisi !!',
        ]);

        if (Request()->foto <> "") { //foto adalah data tavel yg ada di localhost/phpmyadmin tabel staff kolom foto
        // upload foto
        // Jika ingin ganti foto
        $file = Request()->foto; //foto adalah data tabel yg ada di localhost/phpmyadmin tabel foto
        $fileName = Request()->nip . '.' . $file->extension();
        $file->move(public_path('foto_staff'), $fileName); //foto_staff adalah nama folder yg ada di public foto_staff

        $data = [
            'nama_staff' => Request()->nama_staff,
            'nip' => Request()->nip,
            'bagian' => Request()->bagian,
            'alamat' => Request()->alamat,
            'foto' => $fileName, //foto adalah data tabel yg ada di localhost/phpmyadmin tabel foto
        ];
            $this->StaffModel->editData($id_staff, $data);
        } else {
            // Jika tidak ingin ganti foto
            $data = [
                'nama_staff' => Request()->nama_staff,
                'nip' => Request()->nip,
                'bagian' => Request()->bagian,
                'alamat' => Request()->alamat,
            ];
                $this->StaffModel->editData($id_staff, $data);

        }
 
        return redirect()->route('staff')->with('pesan', 'Data Berhasil Diupdate !!!'); // 'staff' adalah halaman staff
    }

    public function delete($id_staff)
    {
        //Hapus Foto yang ada di Folder Public foto_staff
        $staff = $this->StaffModel->detailData($id_staff);
        if($staff->foto <> "")
        {
            unlink(public_path('foto_staff') . '/' . $staff->foto);
        }

        $this->StaffModel->deleteData($id_staff);
        return redirect()->route('staff')->with('pesan', 'Data Berhasil Dihapus !!!'); // 'staff' adalah halaman staff

    }
}
