<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\GuruModel;

class GuruController extends Controller
{
    public function __construct()
    {
        $this->GuruModel = new GuruModel();
        $this->middleware('auth');
    }

    public function index()
    {
        $data = [
            'guru' => $this->GuruModel->allData(),
        ];
        // view('guru/guru') adalah file guru.blade.php yg ada di folder guru
        return view('guru/guru', $data);
    }

    public function detail($id_guru)
    {
        if (!$this->GuruModel->detailData($id_guru))
        {
            abort(404);
        }
        $data = [
            'guru' => $this->GuruModel->detailData($id_guru),
        ];
        // view('guru/detailguru') adalah file detailguru.blade.php yang ada di folder guru
        return view('guru/detailguru', $data);      
    }

    public function tambah()
    {
        // view('guru/tambahguru') adalah file tambahguru.blade.php yang ada di folder guru
        return view('guru/tambahguru');
    }

    public function insert()
    {
        // Jika ada data kosong saat Tambah
        Request()->validate([
            'nama_guru'=>'required',
            'nip'=>'required|unique:guru,nip|min:4|max:11',
            'mapel'=>'required',
            'alamat'=>'required',
            'foto'=>'required|mimes:jpg,jpeg,bmp,png|max:1024',
        ],[
            // variable yg ada di table localhost/phpmyadmin
            'nama_guru.required' => 'Wajib diisi !!',
            'nip.required' => 'Wajib diisi !!',
            'nip.unique' => 'NIP ini sudah ada !!',
            'nip.min' => 'Min. 4 Karakter !!',
            'nip.max' => 'Max. 11 Karakter !!',
            'mapel.required' => 'Wajib diisi !!',
            'alamat.required' => 'Wajib diisi !!',
            'foto.required' => 'Wajib diisi !!',

        ]);

        // upload foto
        $file = Request()->foto; //foto adalah data tabel yg ada di localhost/phpmyadmin tabel foto
        $fileName = Request()->nip . '.' . $file->extension();
        $file->move(public_path('foto_guru'), $fileName); //foto_guru adalah nama folder yg ada di public foto_guru

        $data = [
            'nama_guru' => Request()->nama_guru,
            'nip' => Request()->nip,
            'mapel' => Request()->mapel,
            'alamat' => Request()->alamat,
            'foto' => $fileName, //foto adalah data tabel yg ada di localhost/phpmyadmin tabel foto
        ];

        $this->GuruModel->tambahData($data);
        return redirect()->route('guru')->with('pesan', 'Data Berhasil Ditambahkan !!!'); // 'guru' adalah halaman guru
    }

    public function edit($id_guru)
    {
        if (!$this->GuruModel->detailData($id_guru))
        {
            abort(404);
        }
        $data = [
            'guru' => $this->GuruModel->detailData($id_guru),
        ];
        // view('guru/tambahguru') adalah file tambahguru.blade.php yang ada di folder guru
        return view('guru/editguru', $data);
    }

    public function update($id_guru)
    {
        // Jika ada data kosong saat Tambah
        Request()->validate([
            'nama_guru'=>'required',
            'nip'=>'required|min:4|max:11',
            'mapel'=>'required',
            'alamat'=>'required',
            'foto'=>'mimes:jpg,jpeg,bmp,png|max:1024',
        ],[
            // variable yg ada di table localhost/phpmyadmin
            'nama_guru.required' => 'Wajib diisi !!',
            'nip.required' => 'Wajib diisi !!',
            'nip.min' => 'Min. 4 Karakter !!',
            'nip.max' => 'Max. 11 Karakter !!',
            'mapel.required' => 'Wajib diisi !!',
            'alamat.required' => 'Wajib diisi !!',
        ]);

        if (Request()->foto <> "") { //foto adalah data tavel yg ada di localhost/phpmyadmin tabel guru kolom foto
        // upload foto
        // Jika ingin ganti foto
        $file = Request()->foto; //foto adalah data tabel yg ada di localhost/phpmyadmin tabel foto
        $fileName = Request()->nip . '.' . $file->extension();
        $file->move(public_path('foto_guru'), $fileName); //foto_guru adalah nama folder yg ada di public foto_guru

        $data = [
            'nama_guru' => Request()->nama_guru,
            'nip' => Request()->nip,
            'mapel' => Request()->mapel,
            'alamat' => Request()->alamat,
            'foto' => $fileName, //foto adalah data tabel yg ada di localhost/phpmyadmin tabel foto
        ];
            $this->GuruModel->editData($id_guru, $data);
        } else {
            // Jika tidak ingin ganti foto
            $data = [
                'nama_guru' => Request()->nama_guru,
                'nip' => Request()->nip,
                'mapel' => Request()->mapel,
                'alamat' => Request()->alamat,
            ];
                $this->GuruModel->editData($id_guru, $data);

        }
 
        return redirect()->route('guru')->with('pesan', 'Data Berhasil Diupdate !!!'); // 'guru' adalah halaman guru
    }

    public function delete($id_guru)
    {
        //Hapus Foto yang ada di Folder Public foto_guru
        $guru = $this->GuruModel->detailData($id_guru);
        if($guru->foto <> "")
        {
            unlink(public_path('foto_guru') . '/' . $guru->foto);
        }

        $this->GuruModel->deleteData($id_guru);
        return redirect()->route('guru')->with('pesan', 'Data Berhasil Dihapus !!!'); // 'guru' adalah halaman guru

    }
}
