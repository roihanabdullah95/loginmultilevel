<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\SiswaModel;

class SiswaController extends Controller
{
    public function __construct()
    {
        $this->SiswaModel = new SiswaModel();
        $this->middleware('auth');
    }

    public function index()
    {
        $data = [
            'siswa' => $this->SiswaModel->allData(),
        ];
        // view('siswa') adalah file siswa.blade.php
        return view('siswa/siswa', $data);
    }

    public function detail($id_siswa)
    {
        if (!$this->SiswaModel->detailData($id_siswa))
        {
            abort(404);
        }
        $data = [
            'siswa' => $this->SiswaModel->detailData($id_siswa),
        ];
        // view('siswa') adalah file siswa.blade.php
        return view('siswa/detailsiswa', $data);
    }

    public function tambah()
    {
        // view('siswa/tambahsiswa') adalah file tambahsiswa.blade.php yang ada di folder siswa
        return view('siswa/tambahsiswa');
    }

    public function insert()
    {
        // Jika ada data kosong saat Tambah
        Request()->validate([
            'nama_siswa'=>'required',
            'nis'=>'required|unique:siswa,nis|min:4|max:11',
            'email'=>'required',
            'alamat'=>'required',
            'foto'=>'required|mimes:jpg,jpeg,bmp,png|max:1024',
        ],[
            // variable yg ada di table localhost/phpmyadmin
            'nama_siswa.required' => 'Wajib diisi !!',
            'nis.required' => 'Wajib diisi !!',
            'nis.unique' => 'NIS ini sudah ada !!',
            'nis.min' => 'Min. 4 Karakter !!',
            'nis.max' => 'Max. 11 Karakter !!',
            'email.required' => 'Wajib diisi !!',
            'alamat.required' => 'Wajib diisi !!',
            'foto.required' => 'Wajib diisi !!',

        ]);

        // upload foto
        $file = Request()->foto; //foto adalah data tabel yg ada di localhost/phpmyadmin tabel foto
        $fileName = Request()->nis . '.' . $file->extension();
        $file->move(public_path('foto_siswa'), $fileName); //foto_siswa adalah nama folder yg ada di public foto_siswa

        $data = [
            'nama_siswa' => Request()->nama_siswa,
            'nis' => Request()->nis,
            'email' => Request()->email,
            'alamat' => Request()->alamat,
            'foto' => $fileName, //foto adalah data tabel yg ada di localhost/phpmyadmin tabel foto
        ];

        $this->SiswaModel->tambahData($data);
        return redirect()->route('siswa')->with('pesan', 'Data Berhasil Ditambahkan !!!'); // 'siswa' adalah halaman siswa
    }

    public function edit($id_siswa)
    {
        if (!$this->SiswaModel->detailData($id_siswa))
        {
            abort(404);
        }
        $data = [
            'siswa' => $this->SiswaModel->detailData($id_siswa),
        ];
        // view('siswa/tambahsiswa') adalah file tambahsiswa.blade.php yang ada di folder siswa
        return view('siswa/editsiswa', $data);
    }

    public function update($id_siswa)
    {
        // Jika ada data kosong saat Tambah
        Request()->validate([
            'nama_siswa'=>'required',
            'nis'=>'required|min:4|max:11',
            'email'=>'required',
            'alamat'=>'required',
            'foto'=>'mimes:jpg,jpeg,bmp,png|max:1024',
        ],[
            // variable yg ada di table localhost/phpmyadmin
            'nama_siswa.required' => 'Wajib diisi !!',
            'nis.required' => 'Wajib diisi !!',
            'nis.min' => 'Min. 4 Karakter !!',
            'nis.max' => 'Max. 11 Karakter !!',
            'email.required' => 'Wajib diisi !!',
            'alamat.required' => 'Wajib diisi !!',
        ]);

        if (Request()->foto <> "") { //foto adalah data tavel yg ada di localhost/phpmyadmin tabel siswa kolom foto
        // upload foto
        // Jika ingin ganti foto
        $file = Request()->foto; //foto adalah data tabel yg ada di localhost/phpmyadmin tabel foto
        $fileName = Request()->nis . '.' . $file->extension();
        $file->move(public_path('foto_siswa'), $fileName); //foto_siswa adalah nama folder yg ada di public foto_siswa

        $data = [
            'nama_siswa' => Request()->nama_siswa,
            'nis' => Request()->nis,
            'email' => Request()->email,
            'alamat' => Request()->alamat,
            'foto' => $fileName, //foto adalah data tabel yg ada di localhost/phpmyadmin tabel foto
        ];
            $this->SiswaModel->editData($id_siswa, $data);
        } else {
            // Jika tidak ingin ganti foto
            $data = [
                'nama_siswa' => Request()->nama_siswa,
                'nis' => Request()->nis,
                'email' => Request()->email,
                'alamat' => Request()->alamat,
            ];
                $this->SiswaModel->editData($id_siswa, $data);

        }
 
        return redirect()->route('siswa')->with('pesan', 'Data Berhasil Diupdate !!!'); // 'siswa' adalah halaman siswa
    }

    public function delete($id_siswa)
    {
        //Hapus Foto yang ada di Folder Public foto_siswa
        $siswa = $this->SiswaModel->detailData($id_siswa);
        if($siswa->foto <> "")
        {
            unlink(public_path('foto_siswa') . '/' . $siswa->foto);
        }

        $this->SiswaModel->deleteData($id_siswa);
        return redirect()->route('siswa')->with('pesan', 'Data Berhasil Dihapus !!!'); // 'siswa' adalah halaman siswa

    }
}
