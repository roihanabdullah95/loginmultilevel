

<?php $__env->startSection('title'); ?>
    Dashboard|Admin Panel
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h4 class="card-title"> Data Pegawai </h4>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class=" text-primary">
                    <tr>
                      <th>No ID</th>
                      <th>Name</th>
                      <th>NIP</th>
                      <th>BAGIAN</th>
                      <th>ALAMAT</th>
                      <th colspan="2">ACTION</th>  
                    </tr>
                    </thead>
                    <tbody>
                          <tr>
                              <td>A</td>
                              <td>B</td>
                              <td>C</td>
                              <td>D</td>
                              <td>E</td>
                              <td>
                              <a class="btn btn-primary"  href="#">EDIT</a>
                              </td>
                              <td>
                                  <form action="" method="post">
                                      <button class="btn btn-danger">DELETE</button>
                                  </form>
                              </td>
                          </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\loginAdmin\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>